import React from 'react';
import {createStackNavigator} from '@react-navigation/stack'; 
import Dogs from '../components/Dogs';
import Cats from '../components/Cats';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {MaterialCommunityIcons} from '@expo/vector-icons';

//const Stack = createStackNavigator();
const Tab=createBottomTabNavigator();
export default function Navigation(){
  return(
    <Tab.Navigator>
      <Tab.Screen name="Cats" component={Cats} options={{tabBarLabel:'Cats',tabBarIcon:({color,size})=>(
        <MaterialCommunityIcons name="cat" size={24} color="black"/>
      ),
      }}/>
      <Tab.Screen name="Dogs" component={Dogs} options={{tabBarLabel:'Dogs',tabBarIcon:({color,size})=>(
        <MaterialCommunityIcons name="dog" size={24} color="gray"/>
        ),
        }}/>
    </Tab.Navigator>
  );
}

import React from 'react';
import {View,Text,Image,StyleSheet} from 'react-native';


export default function Cats(){
  return(
    <View style={{flexDirection:'column'}} >
       <View style={styles.contenedor}>
       <Image style={styles.imagen} source={require('../img/Gato.png')} />
       <Text style={styles.texto}>Angora</Text>
       <Text style={styles.subtitulo}>   Turquía</Text>
       </View>

       <View style={styles.contenedor}>
       <Image style={styles.imagen} source={require('../img/gato2.jpg')} />
       <Text style={styles.texto}>Azul Ruso</Text>
       <Text style={styles.subtitulo}>Rusía</Text>
       </View>

      <View style={styles.contenedor}>
       <Image style={styles.imagen} source={require('../img/gato3.jpg')} />
       <Text style={styles.texto}>Maine Coon</Text>
       <Text style={styles.subtitulo}>EE.UU</Text>
      </View>

      <View style={styles.contenedor}>
       <Image style={styles.imagen} source={require('../img/gato4.jpg')} />
       <Text style={styles.texto}>Somalíes</Text>
       <Text style={styles.subtitulo}>EE.UU</Text>
       </View>

      <View style={styles.contenedor}>
       <Image style={styles.imagen} source={require('../img/gato5.jpg')} />
       <Text style={styles.texto}>Persa</Text>
       <Text style={styles.subtitulo}>       Irán</Text>
      </View>

      <View style={styles.contenedor}>
       <Image style={styles.imagen} source={require('../img/gato6.jpeg')} />
       <Text style={styles.texto}>Bengalí </Text>
       <Text style={styles.subtitulo}> Bengala</Text>
      </View>

      <View style={styles.contenedor}>
       <Image style={styles.imagen} source={require('../img/gato7.jpg')} />
       <Text style={styles.texto}>Ragdoll</Text>
       <Text style={styles.subtitulo}>  Inglaterra</Text>
      </View>

    </View> 
  );
}
const styles=StyleSheet.create({
  contenedor:{
   flexDirection:'row'
  },
  texto:{
   padding:20,
   marginLeft:-5,
   fontWeight:'bold',
   alignItems:'left'
  },
  subtitulo:{
    marginLeft:-120,
    padding:40,
    fontStyle:'Italic',
    alignItems:'left'
  },
  imagen:{
    width:90,
    height:70,
    marginTop:10
  }
})

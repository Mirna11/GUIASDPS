import React from 'react';
import {View,Text, Button,Image,StyleSheet} from 'react-native'; 



export default function Dogs(){
return(
    <View style={{flexDirection:'column'}} >
       <View style={styles.contenedor}>
        <Image style={styles.imagen} source={require('../img/perro.jpg')} />
        <Text style={styles.texto}>Golden</Text>
        <Text style={styles.subtitulo}>   Reino Unido</Text>
       </View>

       <View style={styles.contenedor}>
        <Image style={styles.imagen} source={require('../img/perro2.jpg')} />
        <Text  style={styles.texto}>Braco</Text>
        <Text style={styles.subtitulo}>     Alemania</Text>
       </View>

      <View style={styles.contenedor}>
       <Image style={styles.imagen} source={require('../img/husky.jpg')} />
       <Text style={styles.texto}>Husky</Text>
       <Text style={styles.subtitulo}>     Siberia</Text>
      </View>

      <View style={styles.contenedor}>
       <Image style={styles.imagen} source={require('../img/beagle.jpeg')} />
       <Text style={styles.texto}>Beagle</Text>
       <Text style={styles.subtitulo}>   Inglaterra</Text>
       </View>

      <View style={styles.contenedor}>
       <Image style={styles.imagen} source={require('../img/perro5.jpg')} />
       <Text style={styles.texto}>Pointer</Text>
       <Text style={styles.subtitulo}>   Inglaterra</Text>
      </View>

      <View style={styles.contenedor}>
       <Image style={styles.imagen} source={require('../img/dalmata.png')} />
       <Text style={styles.texto}>Dalmata</Text>
       <Text style={styles.subtitulo}>Grecia</Text>
      </View>

      <View style={styles.contenedor}>
       <Image style={styles.imagen} source={require('../img/perro7.jpg')} />
       <Text style={styles.texto}>Chihuahua</Text>
       <Text style={styles.subtitulo}>México</Text>
      </View>

    </View> 
  );
}

const styles=StyleSheet.create({
  contenedor:{
   flexDirection:'row'
  },
  texto:{
   padding:20,
   fontWeight:'bold',
   marginLeft:-5,
  },
  subtitulo:{
   padding:40,
   marginLeft:-120,
   fontStyle:'Italic',
   justifyContent:'left'
  },
  imagen:{
    width:90,
    height:70,
    marginTop:10
  }
})

import React,{useState} from 'react'; 
import {View, StyleSheet, Image , Text, ScrollView,Modal, Button,TouchableHighlight} from 'react-native'; 


const App = () => {  

  const[modalVisiblehabitacion1,setModalVisiblehabitacion1] =useState(false);
  const[modalVisiblehabitacion2,setModalVisiblehabitacion2] =useState(false);
  const[modalVisiblehabitacion3,setModalVisiblehabitacion3] =useState(false);
  const[modalVisibleservicio1,setModalVisibleservicio1] =useState(false);
  const[modalVisibleservicio2,setModalVisibleservicio2] =useState(false);
  const[modalVisibleservicio3,setModalVisibleservicio3] =useState(false);
  const[modalVisiblelugar1,setModalVisiblelugar1] =useState(false);
  const[modalVisiblelugar2,setModalVisiblelugar2] =useState(false);
  const[modalVisiblelugar3,setModalVisiblelugar3] =useState(false);
  const[modalVisiblelugar4,setModalVisiblelugar4] =useState(false);
  return(    
    <>
     <ScrollView>  
        <Modal transparent={true} animationType="slide" visible={modalVisiblehabitacion1} onRequestClose={  () => {
          alert('Modal has been closed.');
         }}>
         <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}> Habitación para dos personas</Text>
            <Text>Cuenta con una pequeña sala, cama matrimonial, baño , ducha, televisión con cable y wifi </Text>
            <Button title="Cerrar" onPress={()=> {setModalVisiblehabitacion1(!modalVisiblehabitacion1)}}></Button>
          </View>
         </View>
        </Modal>

        <Modal transparent={true} animationType="slide" visible={modalVisiblehabitacion2} onRequestClose={  () => {
          alert('Modal has been closed.');
         }}>
         <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Habitación para 1 persona</Text>
            <Text>Cuenta con una vista panoramica a la ciudad , perfecta para disfrutar de una lectura</Text>
            <Button title="Cerrar" onPress={()=> {setModalVisiblehabitacion2(!modalVisiblehabitacion2)}}>
            </Button>
          </View>
         </View>
        </Modal>
        
       <Modal transparent={true} animationType="slide" visible={modalVisiblehabitacion3} onRequestClose={  () => {
          alert('Modal has been closed.');
         }}>
         <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Habitación familiar</Text>
            <Text>Perfecta para el descanso al ser una de las habitaciones más acogedoras del hotel, cuenta con 1 cama matrimonial y 2 personales</Text>
            <Button title="Cerrar" onPress={()=> {setModalVisiblehabitacion3(!modalVisiblehabitacion3)}}>
            </Button>
          </View>
         </View>
        </Modal>

        <Modal transparent={true} animationType="slide" visible={modalVisibleservicio1} onRequestClose={  () => {
          alert('Modal has been closed.');
         }}>
         <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Sala de star </Text>
            <Text>Habitación dedicada para recibir visitas, leer, ver la televisión o realizar otras actividades.</Text>
            <Button title="Cerrar" onPress={()=> {setModalVisibleservicio1(!modalVisibleservicio1)}}>
            </Button>
          </View>
         </View>
        </Modal>
        

        <Modal transparent={true} animationType="slide" visible={modalVisibleservicio2} onRequestClose={  () => {
          alert('Modal has been closed.');
         }}>
         <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Piscinas </Text>
            <Text>Disfrutar de un baño a cualquier hora del día y tomar el sol en compañia de familia o amigos</Text>
            <Button title="Cerrar" onPress={()=> {setModalVisibleservicio2(!modalVisibleservicio2)}}>
            </Button>
          </View>
         </View>
        </Modal>

        <Modal transparent={true} animationType="slide" visible={modalVisibleservicio3} onRequestClose={  () => {
          alert('Modal has been closed.');
         }}>
         <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Juego de billar</Text>
            <Text>Para disfrutar en compañia de amigos, además de disfrutar de los mejores partidos de la Liga </Text>
            <Button title="Cerrar" onPress={()=> {setModalVisibleservicio3(!modalVisibleservicio3)}}>
            </Button>
          </View>
         </View>
        </Modal>


        <Modal transparent={true} animationType="slide" visible={modalVisiblelugar1} onRequestClose={  () => {
          alert('Modal has been closed.');
         }}>
         <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Plaza BAMBÚ</Text>
            <Text>Cuenta con una variedad de tiendas y restaurantes de alta calidad</Text>
            <Button title="Cerrar" onPress={()=> {setModalVisiblelugar1(!modalVisiblelugar1)}}>
            </Button>
          </View>
         </View>
        </Modal>

        <Modal transparent={true} animationType="slide" visible={modalVisiblelugar2} onRequestClose={  () => {
          alert('Modal has been closed.');
         }}>
         <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Plaza Los Olivos</Text>
            <Text>Puedes encontrar una alta variedad de restaurantes</Text>
            <Button title="Cerrar" onPress={()=> {setModalVisiblelugar2(!modalVisiblelugar2)}}>
            </Button>
          </View>
         </View>
        </Modal>

        <Modal transparent={true} animationType="slide" visible={modalVisiblelugar3} onRequestClose={  () => {
          alert('Modal has been closed.');
         }}>
         <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>La Casona </Text>
            <Text>Lugar acojedor y justo para disfrutar del mejor café de El Salvador</Text>
            <Button title="Cerrar" onPress={()=> {setModalVisiblelugar3(!modalVisiblelugar3)}}>
            </Button>
          </View>
         </View>
       </Modal>
       
       <Modal transparent={true} animationType="slide" visible={modalVisiblelugar4} onRequestClose={  () => {
          alert('Modal has been closed.');
         }}>
         <View style={styles.vistaModal}>
          <View style={styles.Modal}>
            <Text style={styles.subtitulo}>Shaw's</Text>
            <Text>Aquí encuentras los mejores chocolates y postres de la ciudad</Text>
            <Button title="Cerrar" onPress={()=> {setModalVisiblelugar4(!modalVisiblelugar4)}}>
            </Button>
          </View>
         </View>
       </Modal>


        <View style={{flexDirection:'row'}}>
          <Image
            style={styles.banner}
            source={require('./src/img/hotel.jpg')} />
        </View>

        <View style={styles.contenedor}>
          <Text style={styles.titulo}>Tipos de habitación</Text>
          <ScrollView horizontal>
            <View>
              <TouchableHighlight
                onPress={()=>{setModalVisiblehabitacion1(!modalVisiblehabitacion1)}}>
              
                <Image
                  style={styles.habitacion}
                  source={require('./src/img/habitacion1.jpg')}
                />
              </TouchableHighlight> 
            </View>

            <View>
               <TouchableHighlight
                onPress={()=>{setModalVisiblehabitacion2(!modalVisiblehabitacion2)}}>
                <Image
                  style={styles.habitacion}
                  source={require('./src/img/habitacion2.jpg')}
                /> 
              </TouchableHighlight> 
            </View>

            <View>
            <TouchableHighlight
                onPress={()=>{setModalVisiblehabitacion3(!modalVisiblehabitacion3)}}>
                <Image
                  style={styles.habitacion}
                  source={require('./src/img/habitacion3.jpg')}
                /> 
              </TouchableHighlight> 
            </View>

            <View>
              <Image
                style={styles.habitacion}
                source={require('./src/img/habitacion4.jpg')}
              /> 
            </View>
          </ScrollView>
            <Text style={styles.titulo}>Servicios para huespedes</Text>
            <View>
                <View>
                  <TouchableHighlight
                   onPress={()=>{setModalVisibleservicio1(!modalVisibleservicio1)}}>
                    <Image
                      style={styles.servicio}
                      source={require('./src/img/servicio1.jpg')}
                    />
                  </TouchableHighlight>  
                </View>

               <View>
                  <TouchableHighlight
                   onPress={()=>{setModalVisibleservicio2(!modalVisibleservicio2)}}>
                   <Image
                    style={styles.servicio}
                    source={require('./src/img/servicio2.jpg')}
                   />
                 </TouchableHighlight> 
               </View>

               <View>
                  <TouchableHighlight
                   onPress={()=>{setModalVisibleservicio3(!modalVisibleservicio3)}}>
                   <Image
                    style={styles.servicio}
                    source={require('./src/img/servicio3.jpg')}
                    />
                  </TouchableHighlight> 
               </View>
             </View>


          <Text style={styles.titulo}>Lugares cercanos</Text>


          <View style={styles.listado}>
            <View style={styles.listaItem}>
             <TouchableHighlight
              onPress={()=>{setModalVisiblelugar1(!modalVisiblelugar1)}}>
                <Image
                  style={styles.servicio}
                  source={require('./src/img/lugar1.jpg')}
                />
             </TouchableHighlight>    
           </View>

           <View style={styles.listaItem}>
             <TouchableHighlight
              onPress={()=>{setModalVisiblelugar2(!modalVisiblelugar2)}}>
              <Image
                style={styles.servicio}
                source={require('./src/img/lugar2.jpg')}
              />
             </TouchableHighlight> 
           </View>

           <View style={styles.listaItem}>
            <TouchableHighlight
              onPress={()=>{setModalVisiblelugar3(!modalVisiblelugar3)}}>
              <Image
                style={styles.servicio}
                source={require('./src/img/lugar3.jpg')}
              />
            </TouchableHighlight> 
           </View>

           <View style={styles.listaItem}>
            <TouchableHighlight
              onPress={()=>{setModalVisiblelugar4(!modalVisiblelugar4)}}>
              <Image
                style={styles.servicio}
                source={require('./src/img/lugar4.jpg')}
              />
            </TouchableHighlight>
           </View>
           
 
         </View>
     </View>
   </ScrollView>
  </>  
  );
}; 

const styles = StyleSheet.create({
   banner:{
      height:250,
      flex:1  
    },
    titulo:{
      fontWeight:'bold',
      fontSize:24,
      marginVertical:10
    },
    contenedor:{
      marginHorizontal:10,
    },
    habitacion:{
      width:250,
      height:300,
      marginRight:10
    },
    servicio:{
      width:'100%',
      height:200,
      marginVertical:5
    },
    listaItem:{
      flexBasis:'49%'
    },
    listado:{
      flexDirection:'row',
      flexWrap:'wrap',
      justifyContent:'space-between'
    },
    vistaModal:{
      backgroundColor:'000000aa',
      flex:1,
    },
    Modal:{
      backgroundColor:'#fff',
      margin:50,
      padding:40,
      borderRadius:10,
      flex:1,
    },
    subtitulo:{
      fontWeight:'bold',
      fontSize:14,
      justifyContent:'center',
    }
});
export default App;
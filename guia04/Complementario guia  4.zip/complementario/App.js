import React,{useState,useEffect} from 'react';
import { SafeAreaView, StyleSheet, View,Text, StatusBar} from 'react-native';
import colors from './src/utils/colors';
import Form from './src/components/Form';
import Footer from './src/components/Footer';
import Result from './src/components/Result';


export default function App() {
  const[nombre,setNombre]=useState(null);
  const [salario,setSalario]=useState(null);
  const [isss,setIsss]=useState(null);
  const [afp,setAfp]=useState(null);
  const [renta,setRenta]=useState(null);
  const [total,setTotal]=useState(null);
  const [errorMessage,setErrorMessage]=useState('');

  useEffect(()=>{
    if(nombre && salario)calculate();
    else reset();
  },[nombre,salario]);

  const calculate=()=>{
    reset();
    if (!nombre) {
  setErrorMessage('Añade el nombre del empleado');
  } else if (!salario) {
  setErrorMessage('Añade el salario base del empleado');
  } else {
  const isss = salario*0.03;
  const afp=salario*0.04;
  const renta=salario*0.05;
  const neto=salario-isss-afp-renta ;
  setTotal({
    isss: (isss).toFixed(2).replace('.', '.'),
    afp: (afp).toFixed(2).replace('.', '.'),
    renta:(renta).toFixed(2).replace('.', '.'),
  totalPayable: (neto).toFixed(2).replace('.', '.'),
  });
  }
 };
  const reset = () => {
  setErrorMessage('');
  setTotal(null);
};
  return (
    <>
      <StatusBar barStyle="light-content"/>
      <SafeAreaView style={styles.Header}>
      <Text style={styles.HeadApp}>Calculo de salario neto</Text>
      <Form
        setNombre={setNombre}
        setSalario={setSalario}
        />
      </SafeAreaView>
       <Result
        nombre={nombre}
        isss={isss}
        afp={afp}
        renta={renta}
        salario={salario}
        total={total}
        errorMessage={errorMessage}
      />
      <Footer calculate={calculate}/>
    </>
  );
}

const styles = StyleSheet.create({
  Header:{
    backgroundColor:'#645CAA',
    height:180,
    borderBottomLeftRadius:30,
    borderBottomRightRadius:30,
    alignItems:'center',
  },
  HeadApp:{
    fontSize:25,
    fontWeight:'bold',
    color:'#fff',
    borderRadius:25,
    marginTop:15,
    justifyContent:'center',
  },
});
